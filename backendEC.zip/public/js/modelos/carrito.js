class CarritoModel {
    carrito = []
}


