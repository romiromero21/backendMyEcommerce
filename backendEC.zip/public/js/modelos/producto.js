class ProductoModel {
    productos = []
}

